﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_Calculator{
    public partial class FrmCalculator : Form{
        #region Private Members
        bool addition = false;
        bool subtrction = false;
        bool multiplication = false;
        bool division = false;
        bool power = false;

        private double? operand1;
        private double? operand2;
        private double? memory;
        private int opOneDecPlace = 0;
        private int opTwoDecPlace = 0;
        private double? result;
        private bool _decimalOn = false;
        private bool MinusOn = false;
        #endregion
        #region Public Members
        /*
        public enum Operation{
            NoneSelected = 0,
            SquareRoot = 1,
            Square = 2,
            Power = 3,
            Reciprocal = 4,

            Division = 5,
            Multiplication = 6,
            Subtraction = 7,
            Addition = 8
        }*/
        #endregion
        #region Form-related methods and events
        public FrmCalculator(){
            InitializeComponent();
            this.KeyPress += new KeyPressEventHandler(FrmCalculator_KeyPress);
        }

        private void FrmCalculator_Load(object sender, EventArgs e){
            equation.Text = result.ToString();
        }
        public void DisplayEquations() {
            equation.Text = operand1.ToString();
            if (addition == true) {
                equation.Text += " + ";
            } else if (subtrction == true) {
                equation.Text += " - ";
            } else if (multiplication == true) {
                equation.Text += " * ";
            } else if (division == true) {
                equation.Text += " / ";
            } else if ( power == true ) {
                equation.Text += " ^ ";
            }
            
            if (operand2 != null) {
                equation.Text += operand2.ToString();
            }        
            return;
        }

        void FrmCalculator_KeyPress(object sender, KeyPressEventArgs e){
            if ((e.KeyChar >= 47 && e.KeyChar <= 57) || (e.KeyChar >= 42 && e.KeyChar <= 43) ||
                e.KeyChar == 45 || e.KeyChar == 61)
            {
                MessageBox.Show("Form.KeyPress: '" + e.KeyChar.ToString() + "' pressed.");

                switch (e.KeyChar)
                {
                    case '1':
                        BtnOne_Click(sender, e);
                        break;
                    case '2':
                        BtnTwo_Click(sender, e);
                        break;
                    case '3':
                        BtnThree_Click(sender, e);
                        break;
                    case '4':
                        BtnFour_Click(sender, e);
                        break;
                    case '5':
                        BtnFive_Click(sender, e);
                        break;
                    case '6':
                        BtnSix_Click(sender, e);
                        break;
                    case '7':
                        BtnSeven_Click(sender, e);
                        break;
                    case '8':
                        BtnEight_Click(sender, e);
                        break;
                    case '9':
                        BtnNine_Click(sender, e);
                        break;
                    case '+':
                        BtnAddition_Click(sender, e);
                        break;
                    case '-':
                        BtnSubtraction_Click(sender, e);
                        break;
                    case '*':
                        BtnMultiplication_Click(sender, e);
                        break;
                    case '/':
                        BtnDivision_Click(sender, e);
                        break;
                    case '=':
                        BtnEquality_Click(sender, e);
                        break;
                    default:
                        MessageBox.Show("Form.KeyPress: '" +
                        e.KeyChar.ToString() + "' consumed.");
                        e.Handled = true;
                        break;
                }
            }
        }
        #endregion
        #region Input/Output Textbox Events
        private void TxtInputOutput_TextChanged(object sender, EventArgs e) {

        }
        #endregion
        #region Power-based Button Events
        private void BtnSquareRoot_Click(object sender, EventArgs e) {
            if (operand1 == null) {
                return;
            }
            
            double swap = Convert.ToDouble(operand1);
            double sqrtResult = Math.Sqrt(swap);

            equation.Text = sqrtResult.ToString();
        }

        private void BtnSquare_Click(object sender, EventArgs e) {
            power = true;
            operand2 = 2;
            result = Math.Pow( Convert.ToDouble(operand1), Convert.ToDouble(operand2) );
            equation.Text = operand1 + " ^ " + operand2 + " = " + result;
        }

        private void BtnReciprocal_Click(object sender, EventArgs e) {
            if (operand1 == null){
                equation.BackColor = Color.Red;
                return; //need an operand to continue
            }
            if (operand1 == 0) {
                equation.BackColor = Color.Red;
                equation.Text = "Cannot divide by zero!";
                return;
            }
            double reciprocal = 1 / Convert.ToDouble(operand1);
            equation.Text = reciprocal.ToString();
            result = reciprocal;
        }
        #endregion

        #region Clear Text Button Events
        private void BtnClearEntry_Click(object sender, EventArgs e) {
            equation.BackColor = Color.White;
            operand1 = null;
            operand2 = null;
            addition = false;
            subtrction = false;
            multiplication = false;
            division = false;
            equation.Text = "";
            result = null;
        }

        private void BtnClearAll_Click(object sender, EventArgs e) {
            equation.BackColor = Color.White;
            operand1 = null;
            operand2 = null;
            addition = false;
            subtrction = false;
            multiplication = false;
            division = false;
            power = false;
            equation.Text = "";
            _decimalOn = false;
            opOneDecPlace = 0;
            opTwoDecPlace = 0;
        }


        private void BtnDelete_Click(object sender, EventArgs e){
            string lastOperand = null;
            int num = 0;
            if (operand2 != null) {
                if (opTwoDecPlace > 0) {
                    opTwoDecPlace--;
                }
                lastOperand = Convert.ToString(operand2.ToString());
                num = Convert.ToInt32(lastOperand.Length);
            } else if (addition == true) {
                addition = false;
            } else if (subtrction == true) {
                subtrction = false;
            } else if (multiplication == true) {
                multiplication = false;
            } else if (division == true) {
                division = false;     
            }else {
                if (opOneDecPlace > 0){
                    opOneDecPlace--;
                }
                lastOperand = Convert.ToString(operand1.ToString());
                num = Convert.ToInt32(lastOperand.Length);
            }

            DisplayEquations();
        }

        #endregion

        private void Numbers(int val) {
            if (MinusOn == false) {
                if (_decimalOn == false) {
                    if (operand1 == null) {
                        operand1 = val;
                    } else if (addition == false && subtrction == false && multiplication == false && division == false && power == false){
                        operand1 = operand1 * 10 + val;
                    } else if (operand2 != null) {
                        operand2 = operand2 * 10 + val;
                    } else {
                        operand2 = val;
                    }
                } else {
                    if (operand1 == null) {
                        opOneDecPlace++;
                        operand1 = val / 10;
                    } else if (addition == false && subtrction == false && multiplication == false && division == false && power == false) {
                        opOneDecPlace++;
                        operand1 += val / Math.Pow(10, opOneDecPlace);
                    } else if (operand2 != null) {
                        opTwoDecPlace++;
                        operand2 += val / Math.Pow(10, opTwoDecPlace);
                    } else {
                        opTwoDecPlace++;
                        operand2 = val / 10;
                    }
                }
            } else {
                if (_decimalOn == false) {
                    if (operand1 == null) {
                        operand1 = val;
                    } else if (addition == false && subtrction == false && multiplication == false && division == false) {
                        operand1 = operand1 * 10 - val;
                    } else if (operand2 != null) {
                        operand2 = operand2 * 10 - val;
                    } else {
                        operand2 = val;
                    }
                } else {
                    if (operand1 == null) {
                        opOneDecPlace++;
                        operand1 = val / 10;
                    } else if (addition == false && subtrction == false && multiplication == false && division == false) {
                        opOneDecPlace++;
                        operand1 -= val / Math.Pow(10, opOneDecPlace);
                    } else if (operand2 != null) {
                        opTwoDecPlace++;
                        operand2 -= val / Math.Pow(10, opTwoDecPlace);
                    } else {
                        opTwoDecPlace++;
                        operand2 = val / 10;
                    }
                }
            }
            return;
        }

        #region Number Button Events
        private void BtnNine_Click(object sender, EventArgs e){
            Numbers(9); DisplayEquations(); return;
        }

        private void BtnEight_Click(object sender, EventArgs e){
            Numbers(8); DisplayEquations(); return;
        }

        private void BtnSeven_Click(object sender, EventArgs e) { 
            Numbers(7); DisplayEquations(); return;
        }

        private void BtnSix_Click(object sender, EventArgs e){
            Numbers(6); DisplayEquations(); return;
        }

        private void BtnFive_Click(object sender, EventArgs e){
            Numbers(5); DisplayEquations(); return;
        }

        private void BtnFour_Click(object sender, EventArgs e){
            Numbers(4); DisplayEquations(); return;
        }
        
        private void BtnThree_Click(object sender, EventArgs e){
            Numbers(3); DisplayEquations(); return;
        }

        private void BtnTwo_Click(object sender, EventArgs e){
            Numbers(2); DisplayEquations(); return;
        }

        private void BtnOne_Click(object sender, EventArgs e){
            Numbers(1); DisplayEquations(); return;
        }

        private void BtnZero_Click(object sender, EventArgs e){
            Numbers(0); DisplayEquations(); return;
        }
        #endregion

        #region Arithmetic Button Events
        private void BtnDivision_Click(object sender, EventArgs e) {
            _decimalOn = false;
            MinusOn = false;
            division = true;
            DisplayEquations();
        }

        private void BtnMultiplication_Click(object sender, EventArgs e) {
            _decimalOn = false;
            MinusOn = false;
            multiplication = true;
            DisplayEquations();
        }

        private void BtnSubtraction_Click(object sender, EventArgs e){
            _decimalOn = false;
            MinusOn = false;
            subtrction = true;
            DisplayEquations();
        }

        private void BtnPower_Click(object sender, EventArgs e) {
            _decimalOn = false;
            MinusOn = false;
            power = true;
            DisplayEquations();
        }

        private void BtnAddition_Click(object sender, EventArgs e) {
            _decimalOn = false;
            MinusOn = false;
            addition = true;
            DisplayEquations();
        }
        #endregion

        #region Other Buttons
        private void BtnEquality_Click(object sender, EventArgs e) {
            if (multiplication == true) {
                result = (double)operand1 * (double)operand2;
                equation.Text = operand1.ToString() + " * " + operand2.ToString() + " = " + result.ToString();
                multiplication = false;
            } else if (division == true) {
                if (operand2 != 0) {
                    result = (double)operand1 / (double)operand2;
                    equation.Text = operand1.ToString() + " / " + operand2.ToString() + " = " + result.ToString();
                } else {
                    equation.Text = "Cannot divide by 0!";
                }
                division = false;
            } else if (addition == true) {
                result = (double)operand1 + (double)operand2;
                equation.Text = operand1.ToString() + " + " + operand2.ToString() + " = " + result.ToString();
                addition = false;
            } else if (subtrction == true) {
                result = (double)operand1 - (double)operand2;
                equation.Text = operand1.ToString() + " - " + operand2.ToString() + " = " + result.ToString();
                subtrction = false;
            } else if ( power == true ) {
                result = Math.Pow(Convert.ToDouble(operand1), Convert.ToDouble(operand2) );
                equation.Text = operand1.ToString() + " ^ " + operand2.ToString() + " = " + result.ToString();
                power = false;
            }
            _decimalOn = false;
            MinusOn = false;
            memory = result;
        }

        private void BtnPlusMinus_Click(object sender, EventArgs e) {
            MinusOn = true;
            if (operand1 == null){
                operand1 = -0.0;
                equation.Text = operand1.ToString();
            } else if (addition == false && subtrction == false && multiplication == false && division == false) {
                operand1 *= -1;
                equation.Text += operand1.ToString();
            } else if (operand2 != null) {
                operand2 *= -1;
                equation.Text += operand2.ToString();
            } else {
                operand2 = -0.0;
                equation.Text += operand2.ToString();
            }
        }

        private void BtnDecimalPoint_Click(object sender, EventArgs e) {
            _decimalOn = true;
            if (operand1 == null){
                operand1 = 0.0;
                equation.Text = operand1.ToString();
            } else if (addition == false && subtrction == false && multiplication == false && division == false) {
                operand1 += .0;
                equation.Text = operand1.ToString();
            } else if (operand2 != null) {
                operand2 = 0.0;
                equation.Text = operand2.ToString();
            } else {
                operand2 += .0;
                equation.Text = operand2.ToString();
            }
        }
        #endregion
        private void Button1_Click(object sender, EventArgs e) {
            if (operand1 == null) {
                operand1 = memory;
            } else if (operand2 == null) { 
                operand2 = memory;
            }
            DisplayEquations();
        }
    }
}
