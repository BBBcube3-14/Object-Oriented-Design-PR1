﻿namespace CSharp_Calculator
{
    partial class FrmCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnSquareRoot = new System.Windows.Forms.Button();
            this.BtnClearEntry = new System.Windows.Forms.Button();
            this.BtnSeven = new System.Windows.Forms.Button();
            this.BtnPlusMinus = new System.Windows.Forms.Button();
            this.BtnOne = new System.Windows.Forms.Button();
            this.BtnFour = new System.Windows.Forms.Button();
            this.BtnEight = new System.Windows.Forms.Button();
            this.BtnClearAll = new System.Windows.Forms.Button();
            this.BtnSquare = new System.Windows.Forms.Button();
            this.BtnZero = new System.Windows.Forms.Button();
            this.BtnTwo = new System.Windows.Forms.Button();
            this.BtnFive = new System.Windows.Forms.Button();
            this.BtnEquality = new System.Windows.Forms.Button();
            this.BtnAddition = new System.Windows.Forms.Button();
            this.BtnSubtraction = new System.Windows.Forms.Button();
            this.BtnMultiplication = new System.Windows.Forms.Button();
            this.BtnDivision = new System.Windows.Forms.Button();
            this.BtnReciprocal = new System.Windows.Forms.Button();
            this.BtnDecimalPoint = new System.Windows.Forms.Button();
            this.BtnThree = new System.Windows.Forms.Button();
            this.BtnSix = new System.Windows.Forms.Button();
            this.BtnNine = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.BtnPower = new System.Windows.Forms.Button();
            this.answer = new System.Windows.Forms.Button();
            this.equation = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnSquareRoot
            // 
            this.BtnSquareRoot.Location = new System.Drawing.Point(31, 44);
            this.BtnSquareRoot.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSquareRoot.Name = "BtnSquareRoot";
            this.BtnSquareRoot.Size = new System.Drawing.Size(56, 39);
            this.BtnSquareRoot.TabIndex = 1;
            this.BtnSquareRoot.Text = "Sqrt";
            this.BtnSquareRoot.UseVisualStyleBackColor = true;
            this.BtnSquareRoot.Click += new System.EventHandler(this.BtnSquareRoot_Click);
            // 
            // BtnClearEntry
            // 
            this.BtnClearEntry.Location = new System.Drawing.Point(31, 92);
            this.BtnClearEntry.Margin = new System.Windows.Forms.Padding(4);
            this.BtnClearEntry.Name = "BtnClearEntry";
            this.BtnClearEntry.Size = new System.Drawing.Size(56, 39);
            this.BtnClearEntry.TabIndex = 2;
            this.BtnClearEntry.Text = "CE";
            this.BtnClearEntry.UseVisualStyleBackColor = true;
            this.BtnClearEntry.Click += new System.EventHandler(this.BtnClearEntry_Click);
            // 
            // BtnSeven
            // 
            this.BtnSeven.Location = new System.Drawing.Point(31, 140);
            this.BtnSeven.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSeven.Name = "BtnSeven";
            this.BtnSeven.Size = new System.Drawing.Size(56, 38);
            this.BtnSeven.TabIndex = 3;
            this.BtnSeven.Text = "7";
            this.BtnSeven.UseVisualStyleBackColor = true;
            this.BtnSeven.Click += new System.EventHandler(this.BtnSeven_Click);
            // 
            // BtnPlusMinus
            // 
            this.BtnPlusMinus.Location = new System.Drawing.Point(31, 278);
            this.BtnPlusMinus.Margin = new System.Windows.Forms.Padding(4);
            this.BtnPlusMinus.Name = "BtnPlusMinus";
            this.BtnPlusMinus.Size = new System.Drawing.Size(56, 38);
            this.BtnPlusMinus.TabIndex = 6;
            this.BtnPlusMinus.Text = "+/-";
            this.BtnPlusMinus.UseVisualStyleBackColor = true;
            this.BtnPlusMinus.Click += new System.EventHandler(this.BtnPlusMinus_Click);
            // 
            // BtnOne
            // 
            this.BtnOne.Location = new System.Drawing.Point(31, 234);
            this.BtnOne.Margin = new System.Windows.Forms.Padding(4);
            this.BtnOne.Name = "BtnOne";
            this.BtnOne.Size = new System.Drawing.Size(56, 39);
            this.BtnOne.TabIndex = 5;
            this.BtnOne.Text = "1";
            this.BtnOne.UseVisualStyleBackColor = true;
            this.BtnOne.Click += new System.EventHandler(this.BtnOne_Click);
            // 
            // BtnFour
            // 
            this.BtnFour.Location = new System.Drawing.Point(31, 185);
            this.BtnFour.Margin = new System.Windows.Forms.Padding(4);
            this.BtnFour.Name = "BtnFour";
            this.BtnFour.Size = new System.Drawing.Size(56, 39);
            this.BtnFour.TabIndex = 4;
            this.BtnFour.Text = "4";
            this.BtnFour.UseVisualStyleBackColor = true;
            this.BtnFour.Click += new System.EventHandler(this.BtnFour_Click);
            // 
            // BtnEight
            // 
            this.BtnEight.Location = new System.Drawing.Point(95, 142);
            this.BtnEight.Margin = new System.Windows.Forms.Padding(4);
            this.BtnEight.Name = "BtnEight";
            this.BtnEight.Size = new System.Drawing.Size(56, 38);
            this.BtnEight.TabIndex = 9;
            this.BtnEight.Text = "8";
            this.BtnEight.UseVisualStyleBackColor = true;
            this.BtnEight.Click += new System.EventHandler(this.BtnEight_Click);
            // 
            // BtnClearAll
            // 
            this.BtnClearAll.Location = new System.Drawing.Point(95, 92);
            this.BtnClearAll.Margin = new System.Windows.Forms.Padding(4);
            this.BtnClearAll.Name = "BtnClearAll";
            this.BtnClearAll.Size = new System.Drawing.Size(56, 39);
            this.BtnClearAll.TabIndex = 8;
            this.BtnClearAll.Text = "C";
            this.BtnClearAll.UseVisualStyleBackColor = true;
            this.BtnClearAll.Click += new System.EventHandler(this.BtnClearAll_Click);
            // 
            // BtnSquare
            // 
            this.BtnSquare.Location = new System.Drawing.Point(95, 44);
            this.BtnSquare.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSquare.Name = "BtnSquare";
            this.BtnSquare.Size = new System.Drawing.Size(56, 39);
            this.BtnSquare.TabIndex = 7;
            this.BtnSquare.Text = "x^2";
            this.BtnSquare.UseVisualStyleBackColor = true;
            this.BtnSquare.Click += new System.EventHandler(this.BtnSquare_Click);
            // 
            // BtnZero
            // 
            this.BtnZero.Location = new System.Drawing.Point(95, 278);
            this.BtnZero.Margin = new System.Windows.Forms.Padding(4);
            this.BtnZero.Name = "BtnZero";
            this.BtnZero.Size = new System.Drawing.Size(56, 38);
            this.BtnZero.TabIndex = 12;
            this.BtnZero.Text = "0";
            this.BtnZero.UseVisualStyleBackColor = true;
            this.BtnZero.Click += new System.EventHandler(this.BtnZero_Click);
            // 
            // BtnTwo
            // 
            this.BtnTwo.Location = new System.Drawing.Point(95, 234);
            this.BtnTwo.Margin = new System.Windows.Forms.Padding(4);
            this.BtnTwo.Name = "BtnTwo";
            this.BtnTwo.Size = new System.Drawing.Size(56, 39);
            this.BtnTwo.TabIndex = 11;
            this.BtnTwo.Text = "2";
            this.BtnTwo.UseVisualStyleBackColor = true;
            this.BtnTwo.Click += new System.EventHandler(this.BtnTwo_Click);
            // 
            // BtnFive
            // 
            this.BtnFive.Location = new System.Drawing.Point(95, 185);
            this.BtnFive.Margin = new System.Windows.Forms.Padding(4);
            this.BtnFive.Name = "BtnFive";
            this.BtnFive.Size = new System.Drawing.Size(56, 39);
            this.BtnFive.TabIndex = 10;
            this.BtnFive.Text = "5";
            this.BtnFive.UseVisualStyleBackColor = true;
            this.BtnFive.Click += new System.EventHandler(this.BtnFive_Click);
            // 
            // BtnEquality
            // 
            this.BtnEquality.Location = new System.Drawing.Point(223, 278);
            this.BtnEquality.Margin = new System.Windows.Forms.Padding(4);
            this.BtnEquality.Name = "BtnEquality";
            this.BtnEquality.Size = new System.Drawing.Size(56, 38);
            this.BtnEquality.TabIndex = 24;
            this.BtnEquality.Text = "=";
            this.BtnEquality.UseVisualStyleBackColor = true;
            this.BtnEquality.Click += new System.EventHandler(this.BtnEquality_Click);
            // 
            // BtnAddition
            // 
            this.BtnAddition.Location = new System.Drawing.Point(223, 234);
            this.BtnAddition.Margin = new System.Windows.Forms.Padding(4);
            this.BtnAddition.Name = "BtnAddition";
            this.BtnAddition.Size = new System.Drawing.Size(56, 39);
            this.BtnAddition.TabIndex = 23;
            this.BtnAddition.Text = "+";
            this.BtnAddition.UseVisualStyleBackColor = true;
            this.BtnAddition.Click += new System.EventHandler(this.BtnAddition_Click);
            // 
            // BtnSubtraction
            // 
            this.BtnSubtraction.Location = new System.Drawing.Point(223, 185);
            this.BtnSubtraction.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSubtraction.Name = "BtnSubtraction";
            this.BtnSubtraction.Size = new System.Drawing.Size(56, 39);
            this.BtnSubtraction.TabIndex = 22;
            this.BtnSubtraction.Text = "--";
            this.BtnSubtraction.UseVisualStyleBackColor = true;
            this.BtnSubtraction.Click += new System.EventHandler(this.BtnSubtraction_Click);
            // 
            // BtnMultiplication
            // 
            this.BtnMultiplication.Location = new System.Drawing.Point(223, 142);
            this.BtnMultiplication.Margin = new System.Windows.Forms.Padding(4);
            this.BtnMultiplication.Name = "BtnMultiplication";
            this.BtnMultiplication.Size = new System.Drawing.Size(56, 38);
            this.BtnMultiplication.TabIndex = 21;
            this.BtnMultiplication.Text = "X";
            this.BtnMultiplication.UseVisualStyleBackColor = true;
            this.BtnMultiplication.Click += new System.EventHandler(this.BtnMultiplication_Click);
            // 
            // BtnDivision
            // 
            this.BtnDivision.Location = new System.Drawing.Point(223, 92);
            this.BtnDivision.Margin = new System.Windows.Forms.Padding(4);
            this.BtnDivision.Name = "BtnDivision";
            this.BtnDivision.Size = new System.Drawing.Size(56, 39);
            this.BtnDivision.TabIndex = 20;
            this.BtnDivision.Text = "/";
            this.BtnDivision.UseVisualStyleBackColor = true;
            this.BtnDivision.Click += new System.EventHandler(this.BtnDivision_Click);
            // 
            // BtnReciprocal
            // 
            this.BtnReciprocal.Location = new System.Drawing.Point(223, 44);
            this.BtnReciprocal.Margin = new System.Windows.Forms.Padding(4);
            this.BtnReciprocal.Name = "BtnReciprocal";
            this.BtnReciprocal.Size = new System.Drawing.Size(56, 39);
            this.BtnReciprocal.TabIndex = 19;
            this.BtnReciprocal.Text = "1/x";
            this.BtnReciprocal.UseVisualStyleBackColor = true;
            this.BtnReciprocal.Click += new System.EventHandler(this.BtnReciprocal_Click);
            // 
            // BtnDecimalPoint
            // 
            this.BtnDecimalPoint.Location = new System.Drawing.Point(159, 278);
            this.BtnDecimalPoint.Margin = new System.Windows.Forms.Padding(4);
            this.BtnDecimalPoint.Name = "BtnDecimalPoint";
            this.BtnDecimalPoint.Size = new System.Drawing.Size(56, 38);
            this.BtnDecimalPoint.TabIndex = 18;
            this.BtnDecimalPoint.Text = ".";
            this.BtnDecimalPoint.UseVisualStyleBackColor = true;
            this.BtnDecimalPoint.Click += new System.EventHandler(this.BtnDecimalPoint_Click);
            // 
            // BtnThree
            // 
            this.BtnThree.Location = new System.Drawing.Point(159, 234);
            this.BtnThree.Margin = new System.Windows.Forms.Padding(4);
            this.BtnThree.Name = "BtnThree";
            this.BtnThree.Size = new System.Drawing.Size(56, 39);
            this.BtnThree.TabIndex = 17;
            this.BtnThree.Text = "3";
            this.BtnThree.UseVisualStyleBackColor = true;
            this.BtnThree.Click += new System.EventHandler(this.BtnThree_Click);
            // 
            // BtnSix
            // 
            this.BtnSix.Location = new System.Drawing.Point(159, 185);
            this.BtnSix.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSix.Name = "BtnSix";
            this.BtnSix.Size = new System.Drawing.Size(56, 39);
            this.BtnSix.TabIndex = 16;
            this.BtnSix.Text = "6";
            this.BtnSix.UseVisualStyleBackColor = true;
            this.BtnSix.Click += new System.EventHandler(this.BtnSix_Click);
            // 
            // BtnNine
            // 
            this.BtnNine.Location = new System.Drawing.Point(159, 142);
            this.BtnNine.Margin = new System.Windows.Forms.Padding(4);
            this.BtnNine.Name = "BtnNine";
            this.BtnNine.Size = new System.Drawing.Size(56, 38);
            this.BtnNine.TabIndex = 15;
            this.BtnNine.Text = "9";
            this.BtnNine.UseVisualStyleBackColor = true;
            this.BtnNine.Click += new System.EventHandler(this.BtnNine_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(159, 92);
            this.BtnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(56, 39);
            this.BtnDelete.TabIndex = 14;
            this.BtnDelete.Text = "Del.";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // BtnPower
            // 
            this.BtnPower.Location = new System.Drawing.Point(159, 44);
            this.BtnPower.Margin = new System.Windows.Forms.Padding(4);
            this.BtnPower.Name = "BtnPower";
            this.BtnPower.Size = new System.Drawing.Size(56, 39);
            this.BtnPower.TabIndex = 13;
            this.BtnPower.Text = "x^y";
            this.BtnPower.UseVisualStyleBackColor = true;
            this.BtnPower.Click += new System.EventHandler(this.BtnPower_Click);
            // 
            // answer
            // 
            this.answer.Location = new System.Drawing.Point(300, 44);
            this.answer.Margin = new System.Windows.Forms.Padding(4);
            this.answer.Name = "answer";
            this.answer.Size = new System.Drawing.Size(79, 39);
            this.answer.TabIndex = 26;
            this.answer.Text = "Answer";
            this.answer.UseVisualStyleBackColor = true;
            this.answer.Click += new System.EventHandler(this.Button1_Click);
            // 
            // equation
            // 
            this.equation.Location = new System.Drawing.Point(34, 15);
            this.equation.Name = "equation";
            this.equation.Size = new System.Drawing.Size(244, 22);
            this.equation.TabIndex = 30;
            // 
            // FrmCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 327);
            this.Controls.Add(this.equation);
            this.Controls.Add(this.answer);
            this.Controls.Add(this.BtnEquality);
            this.Controls.Add(this.BtnAddition);
            this.Controls.Add(this.BtnSubtraction);
            this.Controls.Add(this.BtnMultiplication);
            this.Controls.Add(this.BtnDivision);
            this.Controls.Add(this.BtnReciprocal);
            this.Controls.Add(this.BtnDecimalPoint);
            this.Controls.Add(this.BtnThree);
            this.Controls.Add(this.BtnSix);
            this.Controls.Add(this.BtnNine);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.BtnPower);
            this.Controls.Add(this.BtnZero);
            this.Controls.Add(this.BtnTwo);
            this.Controls.Add(this.BtnFive);
            this.Controls.Add(this.BtnEight);
            this.Controls.Add(this.BtnClearAll);
            this.Controls.Add(this.BtnSquare);
            this.Controls.Add(this.BtnPlusMinus);
            this.Controls.Add(this.BtnOne);
            this.Controls.Add(this.BtnFour);
            this.Controls.Add(this.BtnSeven);
            this.Controls.Add(this.BtnClearEntry);
            this.Controls.Add(this.BtnSquareRoot);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmCalculator";
            this.Text = "C# Calculator";
            this.Load += new System.EventHandler(this.FrmCalculator_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FrmCalculator_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BtnSquareRoot;
        private System.Windows.Forms.Button BtnClearEntry;
        private System.Windows.Forms.Button BtnSeven;
        private System.Windows.Forms.Button BtnPlusMinus;
        private System.Windows.Forms.Button BtnOne;
        private System.Windows.Forms.Button BtnFour;
        private System.Windows.Forms.Button BtnEight;
        private System.Windows.Forms.Button BtnClearAll;
        private System.Windows.Forms.Button BtnSquare;
        private System.Windows.Forms.Button BtnZero;
        private System.Windows.Forms.Button BtnTwo;
        private System.Windows.Forms.Button BtnFive;
        private System.Windows.Forms.Button BtnEquality;
        private System.Windows.Forms.Button BtnAddition;
        private System.Windows.Forms.Button BtnSubtraction;
        private System.Windows.Forms.Button BtnMultiplication;
        private System.Windows.Forms.Button BtnDivision;
        private System.Windows.Forms.Button BtnReciprocal;
        private System.Windows.Forms.Button BtnDecimalPoint;
        private System.Windows.Forms.Button BtnThree;
        private System.Windows.Forms.Button BtnSix;
        private System.Windows.Forms.Button BtnNine;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.Button BtnPower;
        private System.Windows.Forms.Button answer;
        private System.Windows.Forms.TextBox equation;
    }
}

